<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.bpsearch/admin/bpindex_list.php");
?>