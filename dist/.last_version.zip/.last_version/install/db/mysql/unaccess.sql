drop table if exists awz_bpsearch_role;
drop table if exists awz_bpsearch_role_relation;
drop table if exists awz_bpsearch_permission;