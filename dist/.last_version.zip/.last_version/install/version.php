<?
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2025-07-26 05:47:00"
);
?>