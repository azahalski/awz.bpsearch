<?
$arModuleVersion = array(
	"VERSION" => "1.0.3",
	"VERSION_DATE" => "2025-07-30 10:28:00"
);
?>