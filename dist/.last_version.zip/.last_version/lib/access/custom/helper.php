<?php
namespace Awz\Bpsearch\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 0;
}