<?php
namespace Awz\Bpsearch\Access\Custom;

use Awz\Bpsearch\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}