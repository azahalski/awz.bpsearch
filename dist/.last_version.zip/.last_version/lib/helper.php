<?php
namespace Awz\BpSearch;

class Helper {

    const MODULE_ID = 'awz.bpsearch';

}